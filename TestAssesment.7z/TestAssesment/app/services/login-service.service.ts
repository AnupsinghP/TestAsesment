import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { ILogin } from '../utils/common-interfaces';

@Injectable({
  providedIn: 'root'
})
export class LoginServiceService {

  constructor() { }

  login = (username:string,password:string) =>{
    return new Promise((resolve,reject)=>{
      let result = {} as ILogin;
      result.loginSuccessful = false;
      this.postCredentials(username, password).subscribe((resp)=>{
        if(resp){
          result.loginSuccessful = true;
        }
        resolve(result);
      },(error)=>{
        reject(error);
      });
    });

  }

  postCredentials(username:string, password:string): Observable<any>{
    //buismessLogic
    return ;
  }
}
