import { Component, OnInit } from '@angular/core';
import { FormControl, ReactiveFormsModule } from '@angular/forms';
import { LoginServiceService } from '../../services/login-service.service';
import { ILogin } from '../../utils/common-interfaces';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  loginFormControl = new FormControl();
  loginService: LoginServiceService
  constructor(loginSrvc: LoginServiceService) {
    this.loginService = loginSrvc;
  }

  ngOnInit(): void {
  }
  login(){
    this.loginService.login(this.loginFormControl.get("username_ip").value,this.loginFormControl.get("password_ip").value).then((result) => {
      let res:ILogin =result as ILogin;
      if(res.loginSuccessful === true){
        //validUser
      }
    });
  }
}
