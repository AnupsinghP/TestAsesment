export interface ILogin{
    loginSuccessful:boolean;
}